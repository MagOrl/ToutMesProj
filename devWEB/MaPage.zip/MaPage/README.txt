Travail fait par Magomed ARSAMERZOEV de la 11A
mon github : https://github.com/MagomedORLEANS
normalement j'ai fourni les images dans le fichier

rien de plus à signaler.
